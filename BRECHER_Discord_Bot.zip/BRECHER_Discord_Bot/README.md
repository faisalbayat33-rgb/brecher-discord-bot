# BRECHER Discord-Bot – Handyfreundliches Admin-Dashboard

Dieses Projekt baut auf deiner `brecher_bot.py` auf und enthält Bot, SQLite-Datenbank und ein responsives Web-Dashboard. Das Dashboard ist für Handy-Browser optimiert.

## Enthalten
- Admin-Login für das Dashboard
- Einstellungen für Status, Willkommensnachricht und Kanal
- Ticketpanel mit privaten Tickets und Schließen-Button
- XP/Level-System mit XP-Vergabe höchstens einmal pro Minute je Nutzer
- Rangliste im Dashboard und per `!rangliste`
- Anti-Link-Schutz
- Moderationsbefehle: `!clear`, `!kick`, `!ban`
- `!level`, `!help`, `!ticketpanel`

## 1. Discord-Bot anlegen
1. Öffne https://discord.com/developers/applications und erstelle eine Application.
2. Unter **Bot** den Bot erstellen und den Token kopieren. Den Token niemals veröffentlichen.
3. Unter **Bot → Privileged Gateway Intents** aktiviere **Message Content Intent** und **Server Members Intent**.
4. Lade den Bot über **OAuth2 → URL Generator** mit den Scopes `bot` und den nötigen Berechtigungen auf deinen Server ein. Benötigt werden mindestens Nachrichten lesen/senden, Nachrichten verwalten, Kanäle verwalten, Mitglieder moderieren/kicken/bannen sowie Embeds und Nachrichtenverlauf.
5. Aktiviere in Discord den Entwicklermodus und kopiere bei Bedarf Kanal-, Kategorie- und Server-IDs.

## 2. Start auf Windows
1. Installiere Python 3.11 oder neuer von https://www.python.org/downloads/ und aktiviere beim Installer „Add Python to PATH“.
2. Entpacke das ZIP in einen eigenen Ordner.
3. Kopiere `.env.example` zu `.env`.
4. Öffne `.env` und trage `DISCORD_TOKEN`, ein starkes `DASHBOARD_PASSWORD` und einen zufälligen `FLASK_SECRET_KEY` ein.
5. Starte `start_windows.bat`.
6. Öffne auf demselben Gerät `http://127.0.0.1:5000`.

## 3. Auf dem Handy öffnen
Bot und Dashboard müssen auf einem PC/VPS oder einem Hosting-Anbieter laufen. Auf dem Handy kannst du das Dashboard im Browser öffnen:
- Im selben WLAN: `http://LOKALE-IP-DES-PC:5000` (die Firewall muss den Port erlauben; nur im vertrauenswürdigen Heimnetz verwenden).
- Von unterwegs: besser einen VPS mit HTTPS und Reverse Proxy oder einen sicheren Hosting-Dienst verwenden. Port 5000 nicht ungeschützt direkt ins Internet freigeben.
- Das Dashboard läuft nicht dauerhaft nur dadurch, dass du die Dateien auf dem Handy speicherst. Android/iOS sind für einen dauerhaft laufenden Discord-Bot ungeeignet.

## 4. Dashboard einrichten
- Im Dashboard anmelden.
- Willkommenskanal-ID eintragen. Nachricht unterstützt `{user}` und `{server}`.
- Optional Ticket-Kategorie-ID eintragen.
- Einstellungen speichern.
- In Discord in den gewünschten Kanal `!ticketpanel` ausführen.

## Sicherheit
- `.env` und `brecher_data.db` nicht öffentlich teilen.
- Ein Bot-Token ist wie ein Passwort. Wenn er versehentlich veröffentlicht wurde, sofort im Discord Developer Portal zurücksetzen.
- Dashboard nur über HTTPS öffentlich bereitstellen. Verwende ein langes, einzigartiges Passwort und einen zufälligen Secret Key.
- Moderationsbefehle prüfen Discord-Berechtigungen; die Bot-Rolle muss über den betroffenen Rollen stehen.
- Die Datenbank speichert XP anhand von Discord-Nutzer-IDs. XP wird serverübergreifend zusammengeführt, falls derselbe Bot auf mehreren Servern läuft.
- Vor dem öffentlichen Betrieb testen. Die Software wird ohne Garantie bereitgestellt.
