@echo off
cd /d "%~dp0"
py -m venv .venv
call .venv\Scripts\activate
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
if not exist .env (
  copy .env.example .env
  echo Bitte zuerst die .env-Datei ausfuellen und start_windows.bat erneut starten.
  pause
  exit /b 1
)
py -m dotenv run -- python bot.py
pause
