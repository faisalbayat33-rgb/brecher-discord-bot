import os
import asyncio
import threading
import sqlite3
from functools import wraps
from datetime import datetime, timezone

import discord
from discord.ext import commands
from discord.ui import View, Button
from flask import Flask, request, redirect, url_for, session, render_template_string, flash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_FILE = os.getenv("BRECHER_DB", os.path.join(BASE_DIR, "brecher_data.db"))
DASHBOARD_HOST = os.getenv("DASHBOARD_HOST", "0.0.0.0")
DASHBOARD_PORT = int(os.getenv("DASHBOARD_PORT", "5000"))

def db():
    conn = sqlite3.connect(DB_FILE, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY, value TEXT NOT NULL DEFAULT ''
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS levels (
            user_id INTEGER PRIMARY KEY, username TEXT NOT NULL DEFAULT '',
            xp INTEGER NOT NULL DEFAULT 0, level INTEGER NOT NULL DEFAULT 1
        )""")
        defaults = {
            "status": "BRECHER ist online",
            "welcome_message": "Willkommen auf dem Server, {user}!",
            "welcome_channel_id": "",
            "ticket_category_id": "",
            "anti_link": "1",
            "guild_id": ""
        }
        for key, value in defaults.items():
            conn.execute("INSERT OR IGNORE INTO settings(key, value) VALUES(?, ?)", (key, value))

def get_setting(key):
    with db() as conn:
        row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else ""

def set_setting(key, value):
    with db() as conn:
        conn.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                     (key, str(value)))

def add_xp(user_id, username, amount=15):
    with db() as conn:
        row = conn.execute("SELECT xp FROM levels WHERE user_id=?", (user_id,)).fetchone()
        xp = (row["xp"] if row else 0) + amount
        level = xp // 100 + 1
        conn.execute("""INSERT INTO levels(user_id, username, xp, level) VALUES(?,?,?,?)
            ON CONFLICT(user_id) DO UPDATE SET username=excluded.username, xp=excluded.xp, level=excluded.level""",
            (user_id, username, xp, level))
        return xp, level

def get_level(user_id):
    with db() as conn:
        row = conn.execute("SELECT xp, level FROM levels WHERE user_id=?", (user_id,)).fetchone()
        return (row["xp"], row["level"]) if row else (0, 1)

def leaderboard(limit=10):
    with db() as conn:
        return conn.execute("SELECT user_id, username, xp, level FROM levels ORDER BY xp DESC LIMIT ?", (limit,)).fetchall()

init_db()

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)
xp_cooldowns = {}

class CloseTicketView(View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Ticket schließen", emoji="🔒", style=discord.ButtonStyle.danger, custom_id="brecher:close_ticket")
    async def close_ticket(self, interaction: discord.Interaction, button: Button):
        if not interaction.user.guild_permissions.manage_channels:
            await interaction.response.send_message("Dafür brauchst du die Berechtigung „Kanäle verwalten“.", ephemeral=True)
            return
        await interaction.response.send_message("Ticket wird geschlossen und in 5 Sekunden gelöscht.")
        await asyncio.sleep(5)
        try:
            await interaction.channel.delete(reason=f"Ticket geschlossen von {interaction.user}")
        except discord.HTTPException:
            pass

class TicketView(View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Ticket erstellen", emoji="📩", style=discord.ButtonStyle.success, custom_id="brecher:create_ticket")
    async def create_ticket(self, interaction: discord.Interaction, button: Button):
        guild = interaction.guild
        if guild is None:
            await interaction.response.send_message("Das funktioniert nur auf einem Server.", ephemeral=True)
            return
        category_id = get_setting("ticket_category_id")
        category = guild.get_channel(int(category_id)) if category_id.isdigit() else None
        # Prevent multiple open tickets per user
        existing = discord.utils.find(
            lambda ch: ch.name == f"ticket-{interaction.user.id}", guild.text_channels
        )
        if existing:
            await interaction.response.send_message(f"Du hast bereits ein Ticket: {existing.mention}", ephemeral=True)
            return
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
        }
        if guild.me:
            overwrites[guild.me] = discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True)
        channel = await guild.create_text_channel(
            name=f"ticket-{interaction.user.id}", category=category, overwrites=overwrites,
            reason=f"Support-Ticket für {interaction.user}"
        )
        await channel.send(
            f"Hallo {interaction.user.mention}! Beschreibe bitte dein Anliegen. Das Team meldet sich.",
            view=CloseTicketView()
        )
        await interaction.response.send_message(f"Dein Ticket wurde erstellt: {channel.mention}", ephemeral=True)

@bot.event
async def on_ready():
    bot.add_view(TicketView())
    bot.add_view(CloseTicketView())
    status = get_setting("status")
    try:
        await bot.change_presence(activity=discord.Game(name=status))
    except discord.HTTPException:
        pass
    print(f"BRECHER eingeloggt als {bot.user} (ID: {bot.user.id})")

@bot.event
async def on_member_join(member):
    channel_id = get_setting("welcome_channel_id")
    if channel_id.isdigit():
        channel = member.guild.get_channel(int(channel_id))
        if channel:
            message = get_setting("welcome_message").replace("{user}", member.mention).replace("{server}", member.guild.name)
            try:
                await channel.send(f"👋 {message}")
            except discord.HTTPException:
                pass

@bot.event
async def on_message(message):
    if message.author.bot:
        return
    if message.guild and get_setting("anti_link") == "1":
        content = message.content.lower()
        has_link = "http://" in content or "https://" in content or "discord.gg/" in content or "www." in content
        if has_link and not message.author.guild_permissions.administrator:
            try:
                await message.delete()
                await message.channel.send(
                    f"🚫 {message.author.mention}, Links sind hier nicht erlaubt.",
                    delete_after=5
                )
            except discord.HTTPException:
                pass
            return
    if message.guild:
        now = asyncio.get_running_loop().time()
        last = xp_cooldowns.get(message.author.id, 0)
        if now - last >= 60:
            add_xp(message.author.id, str(message.author), 15)
            xp_cooldowns[message.author.id] = now
    await bot.process_commands(message)

@bot.command(name="level")
async def level_cmd(ctx, member: discord.Member = None):
    member = member or ctx.author
    xp, lvl = get_level(member.id)
    await ctx.send(f"📊 **{member.display_name}** — Level **{lvl}** · **{xp} XP**")

@bot.command(name="rangliste", aliases=["leaderboard", "top"])
async def leaderboard_cmd(ctx):
    rows = leaderboard(10)
    if not rows:
        await ctx.send("Noch gibt es keine XP-Daten.")
        return
    lines = [f"**{i}.** {row['username']} — Level {row['level']} · {row['xp']} XP" for i, row in enumerate(rows, 1)]
    await ctx.send(embed=discord.Embed(title="🏆 BRECHER Rangliste", description="\n".join(lines), color=0x5865F2))

@bot.command(name="clear")
@commands.has_permissions(manage_messages=True)
async def clear_cmd(ctx, amount: int = 5):
    if amount < 1 or amount > 100:
        await ctx.send("Bitte eine Zahl zwischen 1 und 100 angeben.")
        return
    deleted = await ctx.channel.purge(limit=amount + 1)
    await ctx.send(f"🧹 {len(deleted)-1} Nachrichten gelöscht.", delete_after=5)

@bot.command(name="kick")
@commands.has_permissions(kick_members=True)
async def kick_cmd(ctx, member: discord.Member, *, reason="Kein Grund angegeben"):
    await member.kick(reason=f"{ctx.author}: {reason}")
    await ctx.send(f"👢 {member.mention} wurde gekickt. Grund: {reason}")

@bot.command(name="ban")
@commands.has_permissions(ban_members=True)
async def ban_cmd(ctx, member: discord.Member, *, reason="Kein Grund angegeben"):
    await member.ban(reason=f"{ctx.author}: {reason}")
    await ctx.send(f"🔨 {member.mention} wurde gebannt. Grund: {reason}")

@bot.command(name="ticketpanel")
@commands.has_permissions(administrator=True)
async def ticketpanel_cmd(ctx):
    embed = discord.Embed(
        title="🎫 BRECHER Support",
        description="Klicke auf **Ticket erstellen**, um ein privates Support-Ticket zu öffnen.",
        color=0x5865F2
    )
    await ctx.send(embed=embed, view=TicketView())

@bot.command(name="help")
async def help_cmd(ctx):
    await ctx.send(embed=discord.Embed(
        title="BRECHER Befehle",
        description="`!level [@Nutzer]` · `!rangliste` · `!clear <1-100>` · `!kick @Nutzer [Grund]` · `!ban @Nutzer [Grund]` · `!ticketpanel`",
        color=0x5865F2
    ))

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("⛔ Du hast keine Berechtigung für diesen Befehl.", delete_after=6)
    elif isinstance(error, (commands.MissingRequiredArgument, commands.BadArgument)):
        await ctx.send("⚠️ Eingabe fehlt oder ist ungültig. Nutze `!help`.", delete_after=6)
    elif isinstance(error, commands.CommandNotFound):
        return
    else:
        print(f"Command-Fehler: {error}")
        await ctx.send("Es ist ein Fehler aufgetreten.", delete_after=6)

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "")
if not app.secret_key:
    print("WARNUNG: FLASK_SECRET_KEY fehlt. Das Dashboard-Login bleibt deaktiviert, bis du es setzt.")

CSS = """
:root{color-scheme:dark;--bg:#0b1020;--panel:#141b2e;--panel2:#1c2540;--text:#eef2ff;--muted:#9ba8c7;--accent:#6d7cff;--line:#293452}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at top,#172448,#0b1020 60%);font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif;color:var(--text)}
a{color:#aab5ff}.wrap{max-width:1120px;margin:auto;padding:24px}.top{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:24px}
.brand{font-size:25px;font-weight:850;letter-spacing:.08em}.brand span{color:var(--accent)}.muted{color:var(--muted)}.pill{border:1px solid var(--line);border-radius:999px;padding:8px 12px;color:var(--muted);font-size:13px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.card{background:linear-gradient(145deg,#172039,#12192b);border:1px solid var(--line);border-radius:18px;padding:20px;box-shadow:0 16px 40px #0002}
.card h2{margin:0 0 16px;font-size:17px}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px}.stat{background:var(--panel2);padding:16px;border-radius:14px}.stat b{font-size:25px;display:block}.stat small{color:var(--muted)}
label{display:block;font-size:13px;color:#cbd5f4;margin:14px 0 7px}input,textarea{width:100%;background:#0c1325;border:1px solid #303d60;color:var(--text);border-radius:10px;padding:12px;font:inherit}textarea{min-height:80px;resize:vertical}
.check{display:flex;gap:10px;align-items:center}.check input{width:auto}.btn{display:inline-block;border:0;background:var(--accent);color:white;padding:12px 16px;border-radius:10px;font-weight:700;cursor:pointer;text-decoration:none}.btn.secondary{background:#263253}.btn.full{width:100%;margin-top:18px}
table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:11px 8px;border-bottom:1px solid var(--line)}th{font-size:12px;text-transform:uppercase;color:var(--muted)}
.flash{background:#263253;border:1px solid #46578b;border-radius:10px;padding:12px;margin-bottom:16px}
.login{max-width:440px;margin:8vh auto}.footer{color:var(--muted);font-size:12px;text-align:center;margin:24px}
@media(max-width:700px){.wrap{padding:15px}.grid{grid-template-columns:1fr}.stats{grid-template-columns:1fr 1fr}.brand{font-size:21px}.card{padding:16px}th,td{padding:9px 5px;font-size:13px}}
"""

def page(title, body, **context):
    return render_template_string("""<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#0b1020"><title>{{ title }} · BRECHER</title><style>""" + CSS + """</style></head><body><main class="wrap">""" + body + """</main></body></html>""", title=title, **context)

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

LOGIN_HTML = """
<div class="login card"><div class="brand">BRECHER<span>.</span></div><p class="muted">Admin Control Center · Sicher anmelden</p>
{% for msg in get_flashed_messages() %}<div class="flash">{{ msg }}</div>{% endfor %}
<form method="post"><label>Dashboard-Passwort</label><input type="password" name="password" required autocomplete="current-password"><button class="btn full" type="submit">Anmelden</button></form>
<p class="muted">Passwort wird über die Umgebungsvariable DASHBOARD_PASSWORD gesetzt.</p></div>
"""

DASH_HTML = """
<header class="top"><div><div class="brand">BRECHER<span>.</span></div><div class="muted">Power Control Center</div></div><div><span class="pill">● Dashboard geschützt</span> <a class="btn secondary" href="{{ url_for('logout') }}">Abmelden</a></div></header>
{% for msg in get_flashed_messages() %}<div class="flash">{{ msg }}</div>{% endfor %}
<div class="stats"><div class="stat"><b>{{ users }}</b><small>Spieler mit XP</small></div><div class="stat"><b>{{ total_xp }}</b><small>Gesammelte XP</small></div><div class="stat"><b>{{ 'AN' if config['anti_link']=='1' else 'AUS' }}</b><small>Anti-Link-Schutz</small></div></div>
<form method="post" action="{{ url_for('save') }}">
<div class="grid">
<section class="card"><h2>🤖 Bot-Einstellungen</h2><label>Aktivitätsstatus</label><input name="status" maxlength="128" value="{{ config['status'] }}" required><label>Server-ID (optional, für Anzeige)</label><input name="guild_id" inputmode="numeric" value="{{ config['guild_id'] }}" placeholder="Discord Server-ID"></section>
<section class="card"><h2>👋 Willkommen</h2><label>Willkommensnachricht</label><textarea name="welcome_message" maxlength="1000" required>{{ config['welcome_message'] }}</textarea><p class="muted">Platzhalter: {user} und {server}</p><label>Kanal-ID</label><input name="welcome_channel_id" inputmode="numeric" value="{{ config['welcome_channel_id'] }}" placeholder="z. B. 123456789012345678"></section>
<section class="card"><h2>🎫 Tickets</h2><label>Ticket-Kategorie-ID (optional)</label><input name="ticket_category_id" inputmode="numeric" value="{{ config['ticket_category_id'] }}" placeholder="Kategorie-ID auf Discord"><p class="muted">Danach in Discord `!ticketpanel` in den gewünschten Kanal senden.</p></section>
<section class="card"><h2>🛡️ Schutz & Moderation</h2><label class="check"><input type="checkbox" name="anti_link" {% if config['anti_link']=='1' %}checked{% endif %}> Anti-Link-Schutz aktivieren</label><p class="muted">Administratoren dürfen weiterhin Links posten. Der Bot benötigt „Nachrichten verwalten“.</p><button class="btn full" type="submit">💾 Einstellungen speichern</button></section>
</div></form>
<section class="card" style="margin-top:16px"><h2>🏆 XP-Rangliste</h2><div style="overflow-x:auto"><table><thead><tr><th>#</th><th>Nutzer</th><th>Level</th><th>XP</th></tr></thead><tbody>{% for row in ranks %}<tr><td>{{ loop.index }}</td><td>{{ row['username'] }}</td><td>{{ row['level'] }}</td><td>{{ row['xp'] }}</td></tr>{% else %}<tr><td colspan="4" class="muted">Noch keine XP-Daten vorhanden.</td></tr>{% endfor %}</tbody></table></div></section>
<section class="card" style="margin-top:16px"><h2>⌨️ Befehle</h2><p><code>!help</code> Hilfe · <code>!level [@Nutzer]</code> Level · <code>!rangliste</code> Top 10 · <code>!clear 10</code> Nachrichten löschen · <code>!kick @Nutzer Grund</code> · <code>!ban @Nutzer Grund</code> · <code>!ticketpanel</code> Ticket-Panel</p></section>
<div class="footer">BRECHER · Einstellungen werden lokal in SQLite gespeichert. Teile niemals Bot-Token oder Dashboard-Passwort.</div>
"""

@app.route("/login", methods=["GET", "POST"])
def login():
    password = os.getenv("DASHBOARD_PASSWORD", "")
    if not app.secret_key or not password:
        return page("Setup erforderlich", '<div class="login card"><h2>Dashboard noch nicht konfiguriert</h2><p>Setze FLASK_SECRET_KEY und DASHBOARD_PASSWORD in deiner .env-Datei und starte den Bot erneut.</p></div>'), 503
    if request.method == "POST":
        if request.form.get("password", "") == password:
            session.clear()
            session["logged_in"] = True
            return redirect(url_for("dashboard"))
        flash("Passwort ist falsch.")
    return page("Login", LOGIN_HTML)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/", methods=["GET"])
@login_required
def dashboard():
    config = {k: get_setting(k) for k in ["status","welcome_message","welcome_channel_id","ticket_category_id","anti_link","guild_id"]}
    ranks = leaderboard(10)
    with db() as conn:
        stats = conn.execute("SELECT COUNT(*) AS users, COALESCE(SUM(xp),0) AS total_xp FROM levels").fetchone()
    return page("Dashboard", DASH_HTML, config=config, ranks=ranks, users=stats["users"], total_xp=stats["total_xp"])

@app.route("/save", methods=["POST"])
@login_required
def save():
    for key in ["status", "welcome_message", "welcome_channel_id", "ticket_category_id", "guild_id"]:
        value = request.form.get(key, "").strip()
        if key.endswith("_id") or key == "guild_id":
            if value and not value.isdigit():
                flash(f"Ungültige ID bei {key}.")
                return redirect(url_for("dashboard"))
        set_setting(key, value)
    set_setting("anti_link", "1" if request.form.get("anti_link") else "0")
    if bot.is_ready():
        asyncio.run_coroutine_threadsafe(
            bot.change_presence(activity=discord.Game(name=get_setting("status")[:128])),
            bot.loop
        )
    flash("Einstellungen wurden gespeichert.")
    return redirect(url_for("dashboard"))

def run_dashboard():
    # Do not expose the Werkzeug debugger on a public interface.
    app.run(host=DASHBOARD_HOST, port=DASHBOARD_PORT, debug=False, use_reloader=False, threaded=True)

if __name__ == "__main__":
    threading.Thread(target=run_dashboard, daemon=True).start()
    token = os.getenv("DISCORD_TOKEN", "")
    if not token:
        raise SystemExit("DISCORD_TOKEN fehlt. Bitte .env-Datei aus .env.example erstellen und ausfüllen.")
    bot.run(token)
